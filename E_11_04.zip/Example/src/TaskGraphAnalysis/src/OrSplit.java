package TaskGraphAnalysis.src;
import java.text.DecimalFormat;

public class OrSplit {
  Node Virtual;

  public boolean OrSplitOf(Node node1, Node node2, double q) {
    double E, SecondM, V, c;
    if (q < 0 || q > 1) {
      System.out.println("add OrSplit error: Invalid Probability1!");
      return false;
    }
    double h11 = node1.geth1();
    double h12 = node1.geth2();
    double q1 = node1.getq();
    double h21 = node2.geth1();
    double h22 = node2.geth2();
    double q2 = node2.getq();
    E = q * (h11 + q1 * h12) + (1 - q) * (h21 + q2 * h22);
    SecondM = q * (h11 * h11 + 2 * q1 * h12 * h12 + 2 * q1 * h11 * h12) + (1 - q) * (h21 * h21 + 2 * q2 * h22 * h22 + 2 * q2 * h21 * h22);
    if (E == 0) {
      System.out.println("add OrSplit error: E is 0!");
      return false;
    }
    V = SecondM - Math.pow(E, 2);
    c = Math.sqrt(V / Math.pow(E, 2));
    this.Virtual = new Node(E, c);
    Node.CountDecre();
    Node.CountDecre();
    /*
     * if(OrSplit.verify(node1,node2,this.Virtual,q)){ return true; } else {
     * System.out.println("add OrSplit failed!"); return false; }
     */
    return true;
  }

  public static boolean verify(Node node1, Node node2, Node virtual, double q) {
    DecimalFormat df = new DecimalFormat("####.00");
    double E_reference = q * node1.getExpectation() + (1 - q) * node2.getExpectation();
    double V_reference = q * node1.getSecM() + (1 - q) * node2.getSecM() - Math.pow(E_reference, 2);
    if (df.format(virtual.getExpectation()).equals(df.format(E_reference))) {
      System.out.println("Orsplit: Expectation Verification ok!");
    } else {
      System.out.println("Orsplit: Expectation Verification wrong!");
      System.out.println("virtual.Expectation is: " + virtual.getExpectation());
      System.out.println("Reference value is: " + E_reference);
      return false;
    }
    if (df.format(virtual.getVar()).equals(df.format(V_reference))) {
      System.out.println("Orsplit: Variation Verification ok!");
    } else {
      System.out.println("Orsplit: Variation Verification wrong!");
      System.out.println("virtual.Variation is: " + virtual.getVar());
      System.out.println("Reference value is: " + V_reference);
      return false;
    }
    return true;
  }
}
