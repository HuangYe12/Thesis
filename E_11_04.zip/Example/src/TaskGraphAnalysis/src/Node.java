package TaskGraphAnalysis.src;
public class Node {
  private static int count;
  private double Expectation;
  private double Coefficient;
  private double Var;
  private String Description;
  // Mixed Phase-Type Model
  private double h1, h2, q;

  // two static method to increase or decrease count
  public static void CountIncre() {
    count = count++;
  }

  public static void CountDecre() {
    count = count--;
  }
  
  // Constructor by Expectation & Coefficient
  public Node(double gMean, double sMean, String Description) {
    if (gMean < 0 || sMean < 0 || sMean/gMean >= 1) {
      System.out.println("Invalid Coefficient input!");
      return;
    } 
    this.Expectation = 1/((1/sMean)-(1/gMean));
    this.Var = Math.pow(Expectation, 2);
    this.Coefficient = Math.sqrt(this.Var)/this.Expectation;
    
    if (this.Coefficient <= 1) {
      this.q = 1.0;
      this.h1 = this.Expectation * (1 - this.Coefficient);
      this.h2 = this.Coefficient * this.Expectation;
    } else {
      this.q = 2.0 / (1 + Math.pow(this.Coefficient, 2));
      this.h1 = 0.0;
      this.h2 = this.Expectation * (1 + Math.pow(this.Coefficient, 2)) / 2.0;
    }
    this.Description = Description;
    Node.CountIncre();
  }

  // Constructor by Expectation & Coefficient
  public Node(double Expectation, double Coefficient) {
    if (Coefficient < 0 || Expectation <= 0) {
      System.out.println("Invalid Coefficient input!");
      return;
    } else if (Coefficient <= 1) {
      this.q = 1.0;
      this.h1 = Expectation * (1 - Coefficient);
      this.h2 = Coefficient * Expectation;
    } else {
      this.q = 2.0 / (1 + Math.pow(Coefficient, 2));
      this.h1 = 0.0;
      this.h2 = Expectation * (1 + Math.pow(Coefficient, 2)) / 2.0;
    }
    this.Expectation = Expectation;
    this.Coefficient = Coefficient;
    this.Var = Math.pow(Coefficient, 2) * Math.pow(Expectation, 2);
    Node.CountIncre();
  }

  // Constructor by h1, h2 & q
  public Node(double h1, double h2, double q) {
    if (q < 0 || q > 1 || ((h1 + q * h2) <= 0) || h1 < 0 || h2 < 0) {
      System.out.println("Invalid probability input!");
      return;
    }
    this.Expectation = h1 + q * h2;
    this.Coefficient = Math.sqrt(q * (2 - q) * Math.pow(h2, 2) / Math.pow((h1 + q * h2), 2));
    this.Var = Math.pow(this.Coefficient, 2) * Math.pow(this.Expectation, 2);
    this.h1 = h1;
    this.h2 = h2;
    this.q = q;
    Node.CountIncre();
  }

  // get methods to get the node info
  public double getExpectation() {
    return this.Expectation;
  }

  public double getCoefficient() {
    return this.Coefficient;
  }

  public double getVar() {
    return this.Var;
  }

  public double geth1() {
    return this.h1;
  }

  public double geth2() {
    return this.h2;
  }

  public double getq() {
    return this.q;
  }

  public double getSecM() {
    double SecM = Math.pow(this.geth1(), 2) + 2 * this.getq() * Math.pow(this.geth2(), 2) + 2 * this.getq() * this.geth1() * this.geth2();
    return SecM;
  }

}
