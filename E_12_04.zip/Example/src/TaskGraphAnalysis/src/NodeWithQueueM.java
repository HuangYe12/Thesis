package TaskGraphAnalysis.src;

public class NodeWithQueueM {
	  public static Node CreateNode(double InputMean, double ServMean, double ServCo)
	  {
		  if (InputMean <= ServMean || ServMean <= 0 || ServCo < 0) {
			  System.out.println("Invalid Parameter input!");
		      return new Node(0, -1);
		      }
		  double E, Co, MeanDelay, fi, DelaySecM, lambda, VAR;
		  Node Server = new Node(ServMean, ServCo);
		  lambda = 1/InputMean;
		  fi = lambda * ServMean;
		  MeanDelay = lambda * Server.getSecM() / (2 * (1 - fi));
		  E = Server.getExpectation() + MeanDelay;
		  DelaySecM = Math.pow(lambda * Server.getSecM() / (1-fi), 2) / 2 
				  + (lambda * Server.getThirdM()) / (3 * (1-fi)); 
		  VAR = DelaySecM - Math.pow(MeanDelay, 2) + Server.getVar();
		  Co = Math.sqrt(VAR / Math.pow(E, 2));
		  return new Node(E, Co);
	  }
}
