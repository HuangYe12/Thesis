package TaskGraphAnalysis.src;

public class testcases {
  // the first test case, test the M_G_n queue
  public static void FirstCase() {
    double ServM = 1.0;
    String Filename = "TestCase_M_G_n.dat";
    int[] nArray = {1, 2, 10, 100};
    double[] ServCoArray = {0.0, 0.5, 1.0, 2.0, 3.0, 5.0};
    double[][] A_nArray = { {0.1, 0.5, 0.95}, {0.2, 0.6, 0.95}, {0.4, 0.7, 0.95}, {0.8, 0.9, 0.95}};
    int i = 0;
    for (int n : nArray) {
      for (double ServCo : ServCoArray) {
        for (double A_n : A_nArray[i]) {
          if (ServCo <= 1.0) {
            Queue.M_Hypo_n(ServM, ServCo, A_n, n, Filename);
          } else {
            Queue.M_Hyper_n(ServM, ServCo, A_n, n, Filename);
          }
        }
      }
      i++;
    }
  }

  // end of the first test case

  // the second test case, test the GI_G_n queue
  public static void SecondCase() {
    double ServM = 1.0;
    String Filename = "Case2.dat";
    int[] nArray = {1, 10, 100};
    double[] ServCoArray = {0.0, 0.5, 2.0, 2.5};
    double[] ArrvCoArray = {0.0, 0.5, 2.0, 2.5};
    double[][] A_nArray = { {0.2, 0.5, 0.95}, {0.4, 0.7, 0.95}, {0.8, 0.9, 0.95}};
    // W(delay probability) for the GI_M_n queue
    double[][][] WArray_GI_M_n = {
        // n=1 n=10 n=100
        { {0.00698, 0.20319, 0.90169}, {0.0006, 0.7299, 0.73689}, {0.00108, 0.08837, 0.44836}},// ca=0
        { {0.04298, 0.30193, 0.92082}, {0.00052, 0.11315, 0.76893}, {0.00342, 0.12450, 0.49554}},// ca=0.5
        { {0.30757, 0.68377, 0.97936}, {0.05826, 0.44876, 0.90530}, {0.12160, 0.42270, 0.73393}},// ca=2.0
        { {0.33375, 0.73739, 0.98567}, {0.09326, 0.54418, 0.92780}, {0.19396, 0.50593, 0.78093}}// ca=2.5
        };
    // w1(waiting time) for the GI_M_n queue
    double[][][] w1Array_GI_M_n = new double[4][3][3];
    // tw(waiting time) for the GI_M_n queue
    double[][][] twArray_GI_M_n = {
        // n=1 n=10 n=100
        { {1.007, 1.255, 10.17}, {0.1120, 0.1876, 1.017}, {0.0269, 0.0518, 0.1267}}, // ca=0
        { {1.045, 1.433, 12.63}, {0.1244, 0.2237, 1.263}, {0.0327, 0.0638, 0.1575}}, // ca=0.5
        { {1.444, 3.162, 48.45}, {0.2350, 0.6573, 4.845}, {0.1082, 0.2341, 0.6096}}, // ca=2.0
        { {1.501, 3.808, 69.78}, {0.2659, 0.8854, 6.978}, {0.1509, 0.3343, 0.8792}} // ca=2.5
        };
    // W(delay probability) for the GI_G_1 queue
    double[][][] WArray_GI_G_1 = {
        // ch=0 ch=0.5 ch=2.0 ch=2.5
        { {0.0, 0.0, 0.0}, {0.005, 0.091, 0.835}, {0.036, 0.286, 0.919}, {0.043, 0.301, 0.922}},// ca=0
        { {0.021, 0.188, 0.903}, {0.027, 0.225, 0.913}, {0.063, 0.338, 0.928}, {0.072, 0.349, 0.930}},// ca=0.5
        { {0.283, 0.688, 0.979}, {0.283, 0.685, 0.979}, {0.280, 0.667, 0.975}, {0.279, 0.657, 0.972}},// ca=2.0
        { {0.293, 0.710, 0.983}, {0.293, 0.709, 0.983}, {0.291, 0.694, 0.979}, {0.290, 0.687, 0.978}} // ca=2.5
        };
    // w1(waiting time) for the GI_G_1 queue
    double[][][] w1Array_GI_G_1 = {
        // ch=0 ch=0.5 ch=2.0 ch=2.5
        { {0.0, 0.0, 0.0}, {0.0000, 0.0087, 2.064}, {0.2567, 1.693, 37.67}, {0.5099, 2.809, 59.04}},// ca=0
        { {0.0001, 0.0279, 2.195}, {0.0031, 0.1181, 4.566}, {0.3733, 1.946, 40.19}, {0.6451, 3.068, 61.56}},// ca=0.5
        { {0.2744, 1.375, 36.60}, {0.3287, 1.655, 40.29}, {0.8869, 3.711, 75.43}, {1.179, 4.867, 96.87}},// ca=2.0
        { {0.3390, 2.053, 56.93}, {0.4552, 2.263, 59.55}, {1.061, 4.555, 96.23}, {1.366, 5.746, 117.8}} // ca=2.5
        };
    // tw(waiting time) for the GI_G_1 queue
    double[][][] twArray_GI_G_1 = new double[4][4][3];
    // for n=1 GI_G_1 queue
    for (double ArrvCo : ArrvCoArray) {
      for (double ServCo : ServCoArray) {
        for (double A : A_nArray[0]) {
          Queue.GI_G_1(ServM, ServCo, ArrvCo, A, Filename);
        }
      }
    }
    for (int i = 0; i <= 2; i++) { // i is index of the the number of servers in the array
      for (int j = 0; j <= 3; j++) { // j is index of the arrival coefficient in the array
        for (int k = 0; k <= 3; k++) { // k is index of the service coefficient in the array
          for (int m = 0; m <= 2; m++) { // m is index of the A/n in the array
            w1Array_GI_M_n[j][i][m] = twArray_GI_M_n[j][i][m] * WArray_GI_M_n[j][i][m];
            twArray_GI_G_1[j][k][m] = w1Array_GI_G_1[j][k][m] / WArray_GI_G_1[j][k][m];
          }
        }
      }
    }

    // for n=10, 100 GI_G_n queue
    for (int i = 1; i <= 2; i++) { // i is index of the the number of servers in the array
      for (int j = 0; j <= 3; j++) { // j is index of the arrival coefficient in the array
        for (int k = 0; k <= 3; k++) { // k is index of the service coefficient in the array
          for (int m = 0; m <= 2; m++) { // m is index of the A/n in the array
            double W = WArray_GI_M_n[j][i][m] * WArray_GI_G_1[j][k][m] / WArray_GI_M_n[j][0][m];
            double w1 = w1Array_GI_M_n[j][i][m] * w1Array_GI_G_1[j][k][m] / w1Array_GI_M_n[j][0][m];
            double tw = twArray_GI_M_n[j][i][m] * twArray_GI_G_1[j][k][m] / twArray_GI_M_n[j][0][m];
            FileIO.writeto(Filename, nArray[i], ArrvCoArray[j], ServCoArray[k], A_nArray[i][m], W, w1, tw);
          }
        }
      }
    }

  }

  // end of the second test case

  // the third test case, graph from the paper Fig.6
  public static void ThirdCase() {
    Model.Graph1();
  }

  // end of the third test case

  // the forth test case, graph from the paper Fig.2a
  public static void ForthCase() {
    Node n1 = new Node(1.0, 0);
    Node n2 = new Node(1.0, 1);
    Node n3 = new Node(2.0, 0);
    Node n4 = new Node(2.0, 1);
    Node n5 = new Node(2.0, 2);
    Node n6 = new Node(2.0, 0);
    Node n7 = new Node(1.0, 1);
    Node n8 = new Node(3.0, 1);
    Node n9 = new Node(1.0, 0);
    double q2 = 0.5;
    double q5 = 0.5;
    double q6 = 0.8;
    AndSplit And34 = new AndSplit();
    And34.AndSplitOf(n3, n4, true);
    AndSplit And35 = new AndSplit();
    And35.AndSplitOf(And34.Virtual, n5, true);
    OrSplit Or25 = new OrSplit();
    Or25.OrSplitOf(n2, And35.Virtual, q2);
    Concatenation Con67 = new Concatenation();
    Con67.SeqOf(n6, n7);
    Iteration Itr67 = new Iteration();
    Itr67.IterationOf(Con67.Virtual, q6);
    OrSplit Or68 = new OrSplit();
    Or68.OrSplitOf(n8, Itr67.Virtual, q5);
    Concatenation Con15 = new Concatenation();
    Con15.SeqOf(n1, Or25.Virtual);
    Concatenation Con18 = new Concatenation();
    Con18.SeqOf(Con15.Virtual, Or68.Virtual);
    Concatenation Con19 = new Concatenation();
    Con19.SeqOf(Con18.Virtual, n9);
    System.out.println("Graph2a:");
    System.out.println("Expectation: " + Con19.Virtual.getExpectation() + "Coefficient: " + Con19.Virtual.getCoefficient());
    /* Give the virtual service time and coefficient to the queue M_G_n: */
    double[] lambdaArray = {0.02957, 0.03, 0.04918, 0.05, 0.068995, 0.07};
    double A_n;
    for (double lambda : lambdaArray) {
      A_n = lambda * Con19.Virtual.getExpectation();
      if (Con19.Virtual.getCoefficient() <= 1.0) {
        Queue.M_Hypo_n(Con19.Virtual.getExpectation(), Con19.Virtual.getCoefficient(), A_n, 1, "Graph2a.dat");
      } else {
        Queue.M_Hyper_n(Con19.Virtual.getExpectation(), Con19.Virtual.getCoefficient(), A_n, 1, "Graph2a.dat");
      }
    }
  }
  // end of the forth test case
  
  // the fifth test case, M/H2'/1/s
  public static void FifthCase() {
	  String Filename = "TestCase_M_H2_1_s.dat";
	  double[] qArray = {0.5}, h2Array ={1}, lambdaArray = {2};
	  int[] sArray = {1,10,30,50,80,100};
	  for(int s : sArray){
		  for(double q : qArray){
			  for(double h2 : h2Array){
				  for(double lambda:lambdaArray){
					  Queue.M_H2p_1_s(q, h2, s, lambda, Filename);
				  }
			  }
		  }
	  }	  
  }
  
  public static void SixthCase() {  
	  double[] generatorMeanArray = {0.085, 0.09, 0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.3, 0.4};
	  for(double generatorMean:generatorMeanArray){
		  Node n1 = new Node(generatorMean, 0.03, "Report to controller");
		  //System.out.println(n1.getExpectation());
		  Node n2 = new Node(generatorMean, 0.04, "Inquiry DB");
		  //System.out.println(n2.getExpectation());
		  Node n3 = new Node(generatorMean, 0.05, "Reply from DB");
		  //System.out.println(n3.getExpectation());
		  Node n4 = new Node(generatorMean, 0.08, "Inform switch1");
		  Node n5 = new Node(generatorMean, 0.04, "Get reply switch1");
		  Node n6 = new Node(generatorMean, 0.08, "Inform switch2");
		  Node n7 = new Node(generatorMean, 0.04, "Get reply switch2");
		  
		  Concatenation Con45 = new Concatenation();
		  Con45.SeqOf(n4, n5);
		  //System.out.println("h1: " + Con45.Virtual.geth1() + " h2: " + Con45.Virtual.geth2() + " q: " + Con45.Virtual.getq());
		  Concatenation Con67 = new Concatenation();
		  Con67.SeqOf(n6, n7);
		  //System.out.println("h1: " + Con67.Virtual.geth1() + " h2: " + Con67.Virtual.geth2() + " q: " + Con67.Virtual.getq());
		  AndSplit And47 = new AndSplit();
		  And47.AndSplitOf(Con45.Virtual, Con67.Virtual, true);
		  //System.out.println("h1: " + And47.Virtual.geth1() + " h2: " + And47.Virtual.geth2() + " q: " + And47.Virtual.getq());
		  Concatenation Con12 = new Concatenation();
		  Con12.SeqOf(n1, n2);
		  Concatenation Con13 = new Concatenation();
		  Con13.SeqOf(Con12.Virtual, n3);
		  Concatenation Con17 = new Concatenation();
		  Con17.SeqOf(Con13.Virtual, And47.Virtual);
		  System.out.println("Expectation: " + Con17.Virtual.getExpectation() + " Coefficient: " + Con17.Virtual.getCoefficient());	
		  
		  
		  /*A_n = lambda * Con15.Virtual.getExpectation();
	      if (Con15.Virtual.getCoefficient() <= 1.0) {
	        Queue.M_Hypo_n(Con15.Virtual.getExpectation(), Con15.Virtual.getCoefficient(), A_n, 1, "MM1Simple.dat");
	      } else {
	        Queue.M_Hyper_n(Con15.Virtual.getExpectation(), Con15.Virtual.getCoefficient(), A_n, 1, "MM1Simple.dat");
	      }
			 */
	  }
  
  }
  
  public static void SeventhCase() { 
	  double[] generatorMeanArray = {0.1, 0.12, 0.14, 0.16, 0.18, 0.2, 0.3, 0.4};
	  for(double generatorMean:generatorMeanArray){
		  Node n1 = NodeWithQueueM.CreateNode(generatorMean, 0.01, 0);
		  Node n2 = NodeWithQueueM.CreateNode(generatorMean * 0.4, 0.03, 1.2);
		  Node n3 = NodeWithQueueM.CreateNode(generatorMean * 0.3, 0.02, 1.0);
		  Node n4 = NodeWithQueueM.CreateNode(generatorMean * 0.3, 0.015, 1.0);
		  Node n5 = NodeWithQueueM.CreateNode(generatorMean * 0.4, 0.027, 0.8);
		  
		  
		  Concatenation Con12 = new Concatenation();
		  Con12.SeqOf(n1, n2);
		  AndSplit And34 = new AndSplit();
		  And34.AndSplitOf(n3, n4, true);
		  Concatenation Con14 = new Concatenation();
		  Con14.SeqOf(Con12.Virtual, And34.Virtual);
		  Concatenation Con15 = new Concatenation();
		  Con15.SeqOf(Con14.Virtual, n5);
		  System.out.println("Expectation: " + Con15.Virtual.getExpectation() + " Coefficient: " + Con15.Virtual.getCoefficient());	
  }
	 
  }
	  
		
}
