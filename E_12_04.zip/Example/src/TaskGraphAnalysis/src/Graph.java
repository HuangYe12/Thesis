package TaskGraphAnalysis.src;
public class Graph {
  /* the main method: */
  public static void main(String[] args) {
    // constructors test:
    // FileIO.inout();
    // the test case
    //testcases.FirstCase(); /* TEST CASE of M/G/n */
    // testcases.SecondCase();
    //testcases.ThirdCase(); /* TEST CASE of paper graph Fig.6 */
    //testcases.ForthCase(); /* TEST CASE of paper graph Fig.2a */
	 // testcases.FifthCase(); /* TEST M/H2'/1/s
	//testcases.SixthCase(); /* Test M/M/1 simple SDN model */
	  testcases.SeventhCase(); /* Test M/G/1 simple SDN model */
    /* test of the queuing networks */
    // case 1: number of servers = 1
    // Arrival compare: change the arrival coefficient of variation
    /*
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(0.25),"1_SACOV_0.25.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(0.5), "1_SACOV_0.5.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(1.0), "1_SACOV_1.0.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(1.5), "1_SACOV_1.5.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(2.0), "1_SACOV_2.0.dat");
     */
    // Service process compare: change the mean service time
    /*
     * Queue.GI_G_1(0.5,Math.sqrt(1.0), Math.sqrt(1.0), "1_ServM_0.5.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(1.0), "1_ServM_1.0.dat");
     * Queue.GI_G_1(2.0,Math.sqrt(1.0), Math.sqrt(1.0), "1_ServM_2.0.dat");
     * Queue.GI_G_1(4.0,Math.sqrt(1.0), Math.sqrt(1.0), "1_ServM_4.0.dat");
     */
    // Service process compare: change service coefficient of variation
    /*
     * Queue.GI_G_1(1.0,Math.sqrt(0.25), Math.sqrt(1.0),"1_SSCOV_0.25.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(0.5), Math.sqrt(1.0), "1_SSCOV_0.5.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.0), Math.sqrt(1.0), "1_SSCOV_1.0.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(1.5), Math.sqrt(1.0), "1_SSCOV_1.5.dat");
     * Queue.GI_G_1(1.0,Math.sqrt(2.0), Math.sqrt(1.0), "1_SSCOV_2.0.dat");
     */
    /*
     * case 2: number of servers =1, 2, 10, 100 service coefficient of variation <=1 n=1
     * Queue.M_G_n(1.0, Math.sqrt(0.5), 1, "2_M_Hypo_1.dat"); n=2 Queue.M_G_n(1.0, Math.sqrt(0.5),
     * 2, "2_M_Hypo_2.dat"); n=10 Queue.M_G_n(1.0, Math.sqrt(0.5), 10, "2_M_Hypo_10.dat"); n=100
     * Queue.M_G_n(1.0, Math.sqrt(0.5), 100,"2_M_Hypo_100.dat"); service coefficient of variation
     * >=1 n=1 Queue.M_Hyper_n(1.0, Math.sqrt(2.0), 1, "2_M_Hyper_1.dat"); n=2 Queue.M_Hyper_n(1.0,
     * Math.sqrt(2.0), 2, "2_M_Hyper_2.dat"); n=10 Queue.M_Hyper_n(1.0, Math.sqrt(2.0), 10,
     * "2_M_Hyper_10.dat"); n=100 Queue.M_Hyper_n(1.0, Math.sqrt(2.0), 100,"2_M_Hyper_100.dat");
     */
    // case3: Batch arrivals
    // change of the coefficient of variation of the batch sizes N, for each batch unit
    /*
     * Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(0.5), 10, Math.sqrt(0.5),
     * "3_Hox_G_1_a.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(0.5), 10,
     * Math.sqrt(1.0), "3_Hox_G_1_b.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(0.5),
     * 10, Math.sqrt(2.0), "3_Hox_G_1_c.dat");
     *
     * Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(1.0), 10, Math.sqrt(0.5),
     * "3_Mx_G_1_a.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(1.0), 10,
     * Math.sqrt(1.0), "3_Mx_G_1_b.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(1.0),
     * 10, Math.sqrt(2.0), "3_Mx_G_1_c.dat");
     *
     * Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(2.0), 10, Math.sqrt(0.5),
     * "3_Hyx_G_1_a.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(2.0), 10,
     * Math.sqrt(1.0), "3_Hyx_G_1_b.dat"); Queue.Batch_GIx_G_1(1.0, Math.sqrt(1.0), Math.sqrt(2.0),
     * 10, Math.sqrt(2.0), "3_Hyx_G_1_c.dat");
     */

    /*
     * case 4:compare the markovian batch with normal batch Queue.Batch_Mx_G_1(1.0, Math.sqrt(1.0),
     * 10, Math.sqrt(1.0), "4_Mx_M_1.dat"); Queue.M_G_n(10.0, Math.sqrt(1.0), 1, "4_M_M_1.dat");
     * Queue.M_G_n(15.0, Math.sqrt(1.0), 2, "4_M_M_2.dat"); Queue.M_G_n(50.0, Math.sqrt(1.0), 10,
     * "4_M_M_10.dat");
     */

    /*
     * use input output files to test each constructor: Concatenation, AndSplit, OrSplit, Iteration
     * //FileIO.inout();
     *
     * use the graph from paper Model.Graph1();
     *
     * use the graph with 10-parallel tasks int p=10; boolean MaxorMin=true; double Coefficient=0.0;
     * String Filename = "Graph2_0.0.dat"; Model.Graph2(p, MaxorMin, Coefficient, Filename);
     * Coefficient=0.1; Filename = "Graph2_0.1.dat"; Model.Graph2(p, MaxorMin, Coefficient,
     * Filename); Coefficient=0.5; Filename = "Graph2_0.5.dat"; Model.Graph2(p, MaxorMin,
     * Coefficient, Filename); Coefficient=1.0; Filename = "Graph2_1.0.dat"; Model.Graph2(p,
     * MaxorMin, Coefficient, Filename); Coefficient=2.0; Filename = "Graph2_2.0.dat";
     * Model.Graph2(p, MaxorMin, Coefficient, Filename); Coefficient=10.0; Filename =
     * "Graph2_10.0.dat"; Model.Graph2(p, MaxorMin, Coefficient, Filename);
     */
    /* end of the main() method */
  }
  /* end of the class Graph */
}
