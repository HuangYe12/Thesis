package TaskGraphAnalysis.src;
public class Queue {
  /* static methods for queuing networks of all kinds */
  public static void Batch_Mx_G_1(double ServM, double ServCo, double N, double cn, String Filename) {
    double ArrvRate, ServU, w1, W, tw, tr;

    ServM = ServM * N;
    ServCo = Math.sqrt((Math.pow(ServCo, 2) / N) + Math.pow(cn, 2));
    for (ServU = 0.01; ServU <= 0.99; ServU = ServU + 0.01) { // Server Utilization from 0.01 to
                                                              // 0.99
      ArrvRate = ServU / ServM;
      w1 = ServU * (1 + ServCo * ServCo) * ServM / (2 * (1 - ServU)); // mean waiting time with
                                                                      // respect to all
      W = ServU;
      tw = w1 / W;
      tr = w1 + ServM;

      FileIO.writeto(Filename, ServU, ArrvRate, w1, tw, W, tr);
    }
  }

  public static void Batch_GIx_G_1(double ServM, double ServCo, double ArrvCo, double N, double cn, String Filename) {
    double ArrvRate, ServU, w1, W, tw, tr, g, k;

    ServM = ServM * N;
    ServCo = Math.sqrt((Math.pow(ServCo, 2) / N) + Math.pow(cn, 2));
    ArrvCo = Math.sqrt((Math.pow(ArrvCo, 2) / N) + Math.pow(cn, 2));
    for (ServU = 0.01; ServU <= 0.99; ServU = ServU + 0.01) { // Server Utilization from 0.01 to
                                                              // 0.99
      if (ArrvCo < 1) {
        g = Math.exp(2 * (ServU - 1) * Math.pow(1 - ArrvCo * ArrvCo, 2) / (3 * ServU * (ArrvCo * ArrvCo + ServCo * ServCo)));
        k = (1 + Math.pow(ArrvCo, 2) + ServU * Math.pow(ServCo, 2)) / (1 + ServU * (Math.pow(ServCo, 2) - 1) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
      } else {
        g = Math.exp((ServU - 1) * (ArrvCo * ArrvCo - 1) / (ArrvCo * ArrvCo + 4 * ServCo * ServCo));
        k = 4 * ServU / (Math.pow(ArrvCo, 2) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
      }
      ArrvRate = ServU / ServM;
      w1 = ServM * ServU * (ArrvCo * ArrvCo + ServCo * ServCo) * g / (2 * (1 - ServU)); // mean
                                                                                        // waiting
                                                                                        // time with
                                                                                        // respect
                                                                                        // to all
                                                                                        // requests
      W = ServU + (Math.pow(ArrvCo, 2) - 1) * ServU * (1 - ServU) * k; // mean wait probability
      tw = w1 / W; // mean waiting time with respect to the one who needs to wait
      tr = w1 + ServM;
      FileIO.writeto(Filename, ServU, ArrvRate, w1, tw, W, tr);
    }

  }

  public static void GI_G_1(double ServM, double ServCo, double ArrvCo, String Filename) {
    double ArrvRate, ServU, g, k, w1, W, tw, tr;

    for (ServU = 0.01; ServU <= 0.99; ServU = ServU + 0.01) { // Server Utilization from 0.01 to
                                                              // 0.99
      if (ArrvCo < 1) {
        g = Math.exp(2 * (ServU - 1) * Math.pow(1 - ArrvCo * ArrvCo, 2) / (3 * ServU * (ArrvCo * ArrvCo + ServCo * ServCo)));
        k = (1 + Math.pow(ArrvCo, 2) + ServU * Math.pow(ServCo, 2)) / (1 + ServU * (Math.pow(ServCo, 2) - 1) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
      } else {
        g = Math.exp((ServU - 1) * (ArrvCo * ArrvCo - 1) / (ArrvCo * ArrvCo + 4 * ServCo * ServCo));
        k = 4 * ServU / (Math.pow(ArrvCo, 2) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
      }
      ArrvRate = ServU / ServM;
      w1 = ServM * ServU * (ArrvCo * ArrvCo + ServCo * ServCo) * g / (2 * (1 - ServU)); // mean
                                                                                        // waiting
                                                                                        // time with
                                                                                        // respect
                                                                                        // to all
                                                                                        // requests
      W = ServU + (Math.pow(ArrvCo, 2) - 1) * ServU * (1 - ServU) * k; // mean wait probability
      tw = w1 / W; // mean waiting time with respect to the one who needs to wait
      tr = w1 + ServM;
      FileIO.writeto(Filename, ServU, ArrvRate, w1, tw, W, tr);
    }
  }

  /* Servco ranges from 0 to infinity */
  public static void M_G_n(double ServM, double ServCo, int n, String Filename) {
    if (ServCo <= 1) {
      Queue.M_hypo_n(ServM, ServCo, n, Filename);
    } else {
      Queue.M_hyper_n(ServM, ServCo, n, Filename);
    }
  }

  /* approximation equation for ServCo <=1, n range from 1 to 100 */
  public static void M_hypo_n(double ServM, double ServCo, int n, String Filename) {
    // the given ServM is the average service time of one processor
    double ArrvRate, ServU, w1, tw, W, tr;
    double a, b;

    for (ServU = 0.01; ServU < n; ServU = ServU + 0.01) { // Server Utilization from 0.2 to 1.9,
                                                          // because 2 processors
      ArrvRate = ServU / ServM;

      a = SelfMath.Sigma(ServU, n) + (Math.pow(ServU, n) / (SelfMath.Fact(n - 1) * (n - ServU)));
      b = Math.pow(ServU, n + 1) / (SelfMath.Fact(n) * n * Math.pow(1 - (ServU / n), 2) * ArrvRate * a);

      w1 = (Math.pow(ServCo, 2) + 1) * b / 2;
      W = Math.pow(ServU, n) / (a * SelfMath.Fact(n - 1) * (n - ServU));
      tw = w1 / W;
      tr = w1 + ServM;
      FileIO.writeto(Filename, ServU, ArrvRate, w1, tw, W, tr);
    }
  }

  /* hyper exponential case, ServCo>=1, n range from 2 to 100 */
  public static void M_hyper_n(double ServM, double ServCo, int n, String Filename) {
    double ArrvRate, ServU, w1, tw, W, tr;
    double a, b, s, g, part1, q, epsilon;

    q = 2 / (1 + Math.pow(ServCo, 2)); // probability to M branch
    epsilon = 2 / (ServM * (1 + Math.pow(ServCo, 2))); // server processing rate

    for (ServU = 0.01; ServU < n; ServU = ServU + 0.01) { // Server Utilization from 0.01 to 0.99
      ArrvRate = ServU / ServM;
      g = (ArrvRate - ArrvRate * q + n * epsilon) / ArrvRate;
      a = SelfMath.Sigma_extend(n, n, epsilon / (ArrvRate * q));
      b = Math.log10(1e6 + (ArrvRate * q / (n * epsilon - ArrvRate * q)));
      s = (b - Math.log10(a + (n * epsilon / (n * epsilon - ArrvRate * q)))) / Math.log10(g); // space
                                                                                              // for
                                                                                              // waiting
                                                                                              // when
                                                                                              // waiting
                                                                                              // probability
                                                                                              // is
                                                                                              // 1e-6
      part1 = n * epsilon * (Math.pow(g, s) + s - s * g - 1) / (ArrvRate * ArrvRate * (g - 1) * (g - 1));

      w1 = (1 / (1e6 - 1)) * (part1 + (s / ArrvRate)); // mean waiting time with respect to all
      tr = ServM + w1;
      W = 1e-6 * (n * epsilon * (1 - Math.pow(g, s))) / (ArrvRate * (1 - g));
      tw = w1 / W; // mean waiting time with respect to waiting
      FileIO.writeto(Filename, ServU, ArrvRate, w1, tw, W, tr);
    }

  }

  // FOR TEST CASESE:
  public static void GI_G_1(double ServM, double ServCo, double ArrvCo, double ServU, String Filename) {
    double g, k, w1, W, tw;

    if (ArrvCo < 1) {
      g = Math.exp(2 * (ServU - 1) * Math.pow(1 - ArrvCo * ArrvCo, 2) / (3 * ServU * (ArrvCo * ArrvCo + ServCo * ServCo)));
      k = (1 + Math.pow(ArrvCo, 2) + ServU * Math.pow(ServCo, 2)) / (1 + ServU * (Math.pow(ServCo, 2) - 1) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
    } else {
      g = Math.exp((ServU - 1) * (ArrvCo * ArrvCo - 1) / (ArrvCo * ArrvCo + 4 * ServCo * ServCo));
      k = 4 * ServU / (Math.pow(ArrvCo, 2) + Math.pow(ServU, 2) * (4 * Math.pow(ArrvCo, 2) + Math.pow(ServCo, 2)));
    }
    w1 = ServM * ServU * (ArrvCo * ArrvCo + ServCo * ServCo) * g / (2 * (1 - ServU)); // mean
                                                                                      // waiting
                                                                                      // time with
                                                                                      // respect to
                                                                                      // all
                                                                                      // requests
    W = ServU + (Math.pow(ArrvCo, 2) - 1) * ServU * (1 - ServU) * k; // mean wait probability
    tw = w1 / W;
    FileIO.writeto(Filename, 1, ArrvCo, ServCo, ServU, W, w1, tw);
  }

  /* approximation equation for ServCo <=1, n range from 1 to 100 */
  public static void M_Hypo_n(double ServM, double ServCo, double A_n, int n, String Filename) {
    // the given ServM is the average service time of one processor
    double ArrvRate, ServU, w1, tw, W, tr;
    double a, b;

    ServU = A_n * n;
    ArrvRate = ServU / ServM;
    a = SelfMath.Sigma(ServU, n) + (Math.pow(ServU, n) / (SelfMath.Fact(n - 1) * (n - ServU)));
    b = Math.pow(ServU, n + 1) / (SelfMath.Fact(n) * n * Math.pow(1 - (ServU / n), 2) * ArrvRate * a);
    w1 = (Math.pow(ServCo, 2) + 1) * b / 2;
    W = Math.pow(ServU, n) / (a * SelfMath.Fact(n - 1) * (n - ServU));
    tw = w1 / W;
    tr = ServM + w1;
    FileIO.writeto(Filename, n, ServCo, A_n, w1, W, tw, tr);
  }

  /* hyper exponential case, ServCo>=1, n range from 2 to 100 */
  public static void M_Hyper_n(double ServM, double ServCo, double A_n, int n, String Filename) {
    double ArrvRate, ServU, w1, tw, W, tr;
    double s, g, a, b, part1, q, epsilon;

    q = 2 / (1 + Math.pow(ServCo, 2)); // probability to M branch
    epsilon = 2 / (ServM * (1 + Math.pow(ServCo, 2))); // server processing rate
    ServU = A_n * n;
    ArrvRate = ServU / ServM;
    g = (ArrvRate - ArrvRate * q + n * epsilon) / ArrvRate;

    a = SelfMath.Sigma_extend(n, n, epsilon / (ArrvRate * q));
    b = Math.log10(1e6 + (ArrvRate * q / (n * epsilon - ArrvRate * q)));
    s = (b - Math.log10(a + (n * epsilon / (n * epsilon - ArrvRate * q)))) / Math.log10(g); // space
                                                                                            // for
                                                                                            // waiting
                                                                                            // when
                                                                                            // waiting
                                                                                            // probability
                                                                                            // is
                                                                                            // 1e-6
    part1 = n * epsilon * (Math.pow(g, s) + s - s * g - 1) / (ArrvRate * ArrvRate * (g - 1) * (g - 1));

    w1 = (1 / (1e6 - 1)) * (part1 + (s / ArrvRate)); // mean waiting time with respect to all
    W = 1e-6 * (n * epsilon * (1 - Math.pow(g, s))) / (ArrvRate * (1 - g));
    tw = w1 / W; // mean waiting time with respect to waiting
    tr = ServM + w1;
    FileIO.writeto(Filename, n, ServCo, A_n, w1, W, tw, tr);

  }
  //Recursive solution for M/H2'/1/s infinite Source Delay-Loss System
  public static void M_H2p_1_s(double q, double h2, int s, double lambda, String Filename) {
	  double B_prob=0, W_prob=0, w_time=0, tw_time=0, Omega_length=0;
	  double[] P = new double[s+2];
	  double k= 1/h2/lambda; // coefficient
	  //Calculate stationary state prob.
	  P[s+1]=1; //Set a init value for recursive calculate.
	  P[s] = k*P[s+1];
	  double sumProb = P[s+1]+P[s];
	  for(int i=s-1; i>=0; --i){
		  double sum = 0;
		  for(int j=i+2; j<=s+1; j++){
			  sum += P[j]*Math.pow(1-q, j-i-2);
		  }
		  P[i]= k*((lambda*h2+1)*P[i+1]-q*sum);
		  sumProb += P[i];
	  }
	  //Revise P[0] value
	  sumProb -= P[0];
	  P[0] = P[0]/q;
	  sumProb += P[0];
	  
	  //important characteristic performance values
	  B_prob = P[s+1]/sumProb; // Normalize probabilities
	  for(int i=1; i<=s+1; i++){
		  W_prob += P[i];
		  Omega_length += (i-1)*P[i];
	  }
	  //Normalize probabilities
	  W_prob = W_prob/sumProb;
	  Omega_length = Omega_length/sumProb;
	  w_time = Omega_length/(lambda*(1-B_prob));
	  tw_time = Omega_length/(lambda*W_prob);
	  FileIO.writeto(Filename,s,B_prob,W_prob,Omega_length,w_time,tw_time);
	  
  }
  /* end of all static methods */

}
