package TaskGraphAnalysis.src;
public class Model {
  /* Graph from paper: */
  public static void Graph1() {
    /* Case1: all nodes are deterministic nodes, Coefficient of Variation is 0 */
    Node n1_1 = new Node(0.5, 0);
    Node n1_2 = new Node(1, 0);
    Node n1_3 = new Node(1, 0);
    Node n1_4 = new Node(0.5, 0);
    Node V_pp = Model.Graph1_pp(n1_1, n1_2, n1_3, n1_4);
    /* Give the virtual service time and coefficient to the queue M_G_n: */
    System.out.println("Case1_pp:");
    System.out.println("Expectation: " + V_pp.getExpectation() + "Coefficient: " + V_pp.getCoefficient());
    /* PP:n=1 */Queue.M_G_n(V_pp.getExpectation(), V_pp.getCoefficient(), 1, "Graph1_D_PP.dat");
    Node V_sp = Model.Graph1_sp(n1_1, n1_2, n1_3, n1_4);
    /* Give the virtual service time and coefficient to the queue M_G_n: */
    System.out.println("Case1_sp:");
    System.out.println("Expectation: " + V_sp.getExpectation() + "Coefficient: " + V_sp.getCoefficient());
    /* SP:n=2 */Queue.M_G_n(V_sp.getExpectation(), V_sp.getCoefficient(), 2, "Graph1_D_SP.dat");

    /* Case2: nodes' parameters are changed, node2 and node3 follows Poisson distribution */
    Node n2_1 = new Node(0.5, 0);
    Node n2_2 = new Node(1, 1);
    Node n2_3 = new Node(1, 1);
    Node n2_4 = new Node(0.5, 0);
    V_pp = Model.Graph1_pp(n2_1, n2_2, n2_3, n2_4);
    System.out.println("Case2_pp:");
    System.out.println("Expectation: " + V_pp.getExpectation() + "Coefficient: " + V_pp.getCoefficient());
    /* Give the virtual service time and coefficient to the queue M_G_n: */
    /* n=1 */Queue.M_G_n(V_pp.getExpectation(), V_pp.getCoefficient(), 1, "Graph1_M_PP.dat");
    V_sp = Model.Graph1_sp(n2_1, n2_2, n2_3, n2_4);
    System.out.println("Case2_sp:");
    System.out.println("Expectation: " + V_sp.getExpectation() + "Coefficient: " + V_sp.getCoefficient());
    /* Give the virtual service time and coefficient to the queue M_G_n: */
    /* n=1 */Queue.M_G_n(V_sp.getExpectation(), V_sp.getCoefficient(), 2, "Graph1_M_SP.dat");
  }

  /* Graph that with p-parallel tasks and two deterministic task */
  public static void Graph2(int p, boolean MaxorMin, double Coefficient, String Filename) {
    Node n1 = new Node(1.0, 0.0);
    Node n2 = Model.Graph2_reduce(p, MaxorMin, Coefficient);
    Node n3 = new Node(1.0, 0.0);

    Concatenation Con12 = new Concatenation();
    Con12.SeqOf(n1, n2);
    Concatenation Con13 = new Concatenation();
    Con13.SeqOf(Con12.Virtual, n3);
    System.out.println(Filename + " E: " + Con13.Virtual.getExpectation() + " c: " + Con13.Virtual.getCoefficient());
    /* Give the virtual service time and coefficient to the queue M_G_1: */
    Queue.M_G_n(Con13.Virtual.getExpectation(), Con13.Virtual.getCoefficient(), 1, Filename);

  }

  /* steps for parallel processing of Graph1 */
  public static Node Graph1_pp(Node n1, Node n2, Node n3, Node n4) {
    /* Step1: And23 are generated! */
    boolean MaxorMin = true;
    AndSplit And23 = new AndSplit();
    And23.AndSplitOf(n2, n3, MaxorMin);
    /* Step2: Con13 are generated! */
    Concatenation Con13 = new Concatenation();
    Con13.SeqOf(And23.Virtual, n1);
    /* Step3: Con14 are generated! */
    Concatenation Con14 = new Concatenation();
    Con14.SeqOf(Con13.Virtual, n4);

    return Con14.Virtual;
  }

  /* steps for serial processing of Graph1 */
  public static Node Graph1_sp(Node n1, Node n2, Node n3, Node n4) {
    /* Step1: Con23 are generated! */
    Concatenation Con23 = new Concatenation();
    Con23.SeqOf(n2, n3);
    /* Step2: Con13 are generated! */
    Concatenation Con13 = new Concatenation();
    Con13.SeqOf(Con23.Virtual, n1);
    /* Step3: Con14 are generated! */
    Concatenation Con14 = new Concatenation();
    Con14.SeqOf(Con13.Virtual, n4);

    return Con14.Virtual;
  }

  /* steps for reduction of the parallel part of Graph2 */
  public static Node Graph2_reduce(int n, boolean MaxorMin, double c) {
    int i;
    Node n2i = new Node(10.0, c);
    Node v = new Node(10.0, c);
    AndSplit And = new AndSplit();

    for (i = 1; i <= n - 1; i++) {
      And.AndSplitOf(v, n2i, MaxorMin);
      v = And.Virtual;
      And.Virtual = null;
    }
    return v;
  }
  /* end of the class Model */
}
