package TaskGraphAnalysis.src;
import java.text.DecimalFormat;

public class Concatenation {
  Node Virtual;

  public boolean SeqOf(Node node1, Node node2) {
    double E, V, c;
    double h11 = node1.geth1();
    double h12 = node1.geth2();
    double q1 = node1.getq();
    double h21 = node2.geth1();
    double h22 = node2.geth2();
    double q2 = node2.getq();
    E = h11 + q1 * h12 + h21 + q2 * h22;
    V = q1 * (2 - q1) * h12 * h12 + q2 * (2 - q2) * h22 * h22;
    if (E == 0) {
      System.out.println("add Concatenation error: E is 0!");
      return false;
    }
    c = Math.sqrt(V / Math.pow(E, 2));
    this.Virtual = new Node(E, c);
    Node.CountDecre();
    Node.CountDecre();
    /*
     * if(Concatenation.verify(node1,node2,this.Virtual)){ return true; } else {
     * System.out.println("add Concatenation failed!"); return false; }
     */
    return true;
  }

  public static boolean verify(Node node1, Node node2, Node virtual) {
    DecimalFormat df = new DecimalFormat("####.00");
    // Verification of Expectation:
    double E_reference = node1.getExpectation() + node2.getExpectation();

    if (df.format(virtual.getExpectation()).equals(df.format(E_reference))) {
      System.out.println("Concatenation: Expectation Verification ok!");
    } else {
      System.out.println("Concatenation: Expectation Verification wrong!");
      System.out.println("virtual.Expectation is: " + virtual.getExpectation());
      System.out.println("Reference value is: " + E_reference);
      return false;
    }
    // Verification of Variation:
    double V_reference = node1.getVar() + node2.getVar();
    if (df.format(virtual.getVar()).equals(df.format(V_reference))) {
      System.out.println("Concatenation: Variation Verification ok!");
    } else {
      System.out.println("Concatenation: Variation Verification wrong!");
      System.out.println("virtual.Var is: " + virtual.getVar());
      System.out.println("Reference value is: " + V_reference);
      return false;
    }
    return true;
  }
}
