package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ConstantDistribution;
import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.distributions.continuous.NegExpDistribution;
import ikr.simlib.distributions.discrete.DiscreteConstantDistribution;
import ikr.simlib.entities.Entity;
import ikr.simlib.entities.demultiplexers.Demultiplexer;
import ikr.simlib.entities.demultiplexers.StdDemultiplexer;
import ikr.simlib.entities.generators.StdGenerator;
import ikr.simlib.entities.multiplexers.StdMultiplexer;
import ikr.simlib.entities.phases.StdPhase;
import ikr.simlib.entities.queues.QueuingEntity;
import ikr.simlib.entities.sinks.Sink;
import ikr.simlib.events.time.Duration;
import ikr.simlib.factories.Factory;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.Port;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.ports.output.SynchronousOutputPort;
import ikr.simlib.random.RandomNumberGenerator;

public class MG1Node extends Entity{
	private final QueuingEntity queue;
	private final StdPhase phaseM;
	private final StdGenerator additionalGenerator;
	private final StdMultiplexer multiplexer;
	private final Demultiplexer demultiplexer;
	private final Sink additionalsink;
	
	public MG1Node(Parameters pars, SimNode ownNode) {
		super(ownNode);
		final double Expectation = pars.get(simNode, "ServMean").asDouble();
		final double Coefficient = pars.get(simNode, "ServCo").asDouble();
		final double q, h1, h2;
		if (Coefficient <= 1) {
		      q = 1.0;
		      h1 = Expectation * (1 - Coefficient);
		      h2 = Coefficient * Expectation;
		    } else {
		      q = 2.0 / (1 + Math.pow(Coefficient, 2));
		      h1 = 0.0;
		      h2 = Expectation * (1 + Math.pow(Coefficient, 2)) / 2.0;
		    }
		// create entities
		final double mean = pars.get(simNode, "AdditionalTraffic").asDouble();
		if(mean==0)
			this.additionalGenerator = new StdGenerator(new NegExpDistribution(99999999), new DiscreteConstantDistribution(1), this.simNode.createChildNode("AdditionalGenerator"), new AdditionalTrafficFactory(), true);
		else
			this.additionalGenerator = new StdGenerator(new NegExpDistribution(mean), new DiscreteConstantDistribution(1), this.simNode.createChildNode("AdditionalGenerator"), new AdditionalTrafficFactory(), true);
		this.queue = QueuingEntity.createUnboundedFIFOQueue(this.simNode.createChildNode("Queue"));
		//this.phaseD = new StdPhase(new ConstantDistribution(h1), this.simNode.createChildNode("DPhase"));
		this.phaseM = new DegeneratedPhase(new NegExpDistribution(h2), q, this.simNode.createChildNode("MPhase"), new ConstantDistribution(h1));
		this.multiplexer = new StdMultiplexer(this.simNode.createChildNode("Multiplexer"));
		this.demultiplexer = new Demux(this.simNode.createChildNode("Demultiplexer"));
		this.additionalsink = new Sink(this.simNode.createChildNode("AdditionalSink"));
		// connect entities
		if(mean!=0)
			this.additionalGenerator.getOutput().connect((InputPort)this.multiplexer.getPortByName(this.multiplexer.addPort()));
		this.multiplexer.connect("output", this.queue, "input");
		this.queue.connect("output", this.phaseM, "input");
		//this.phaseD.connect("output", this.phaseM, "input");
		this.phaseM.connect("output", this.demultiplexer, "input");
		this.demultiplexer.getOutput(1).connect(additionalsink.getInput());
				
	}
	
	public InputPort getInput() {
	      final String inPortName = this.multiplexer.addPort();
	      return (InputPort) this.multiplexer.getPortByName(inPortName);
	}
	
	public OutputPort getOutput() {
		return (OutputPort) this.demultiplexer.getOutput(0);
	}
	
	//TODO maybe need a separate sink to accept the additional traffic
	
	private class DegeneratedPhase extends StdPhase {	
		private final double q;
		private final ContinuousDistribution d2;
		
		public DegeneratedPhase(ContinuousDistribution d, double q, SimNode ownNode, ContinuousDistribution d2) {
			super(d, ownNode);
			this.q = q;
			this.d2 = d2;
		}
		//TODO probability check
		
		@Override
		protected Duration getMessageProcessingDuration(Message msg) {
			final double prob = RandomNumberGenerator.getSystemRNG().next();
			if(prob <= q) {
				return Duration.fromSeconds(serviceTime.next()+d2.next());
			} else {
				return Duration.fromSeconds(0.0+d2.next());
			}
		}

	}
	
	public class  AdditionalTrafficFactory implements Factory<Message> {

		@Override
		public Message create() {
			return new AdditionalTrafficMessage();
		}
	}
	
	public class AdditionalTrafficMessage extends Message {
		
	}
	
	public class Demux extends Demultiplexer {
		
		OutputPort out1;
		OutputPort out2;
		

		public Demux(SimNode ownNode) {
			super(ownNode);
			out1 =  new OutputPort(this, "output 1") {
		         @Override
		         protected Message handleGetMessage() {
		            return Demux.this.handleGetMessage(this);
		         }

		         @Override
		         protected boolean handleIsMessageAvailable() {
		            return Demux.this.handleIsMessageAvailable(this);
		         }
		      };
		      
		      out2 =  new OutputPort(this, "output 2") {
			         @Override
			         protected Message handleGetMessage() {
			            return Demux.this.handleGetMessage(this);
			         }

			         @Override
			         protected boolean handleIsMessageAvailable() {
			            return Demux.this.handleIsMessageAvailable(this);
			         }
			      };
		}

		@Override
		protected Port determineOutputPort(Message msg) {
			if(msg instanceof AdditionalTrafficMessage) {
				return out2;
			} else {
				return out1;
			}
		}

		@Override
		public OutputPort getOutput(int index) {
			if(index==0) {
				return out1;
			} else {
				return out2;
			}
		}
		
	}

}
