package ikr.simlib.example;

import ikr.simlib.entities.Entity;
import ikr.simlib.entities.branches.Expander;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.ports.output.SynchronousOutputPort;


public class Duplicator extends Entity {
	
	private final Expander<Double> expander;

	public Duplicator(Parameters pars, SimNode ownNode) {
		super(ownNode);
		// create entities
		this.expander = new DuplicatePhase(2, this.simNode.createChildNode("Duplicator"));
	
	}
	
	public InputPort getInput() {
		return (InputPort) this.expander.getPortByName("input");
	}

	public OutputPort getOutput(String portName) {
		return (OutputPort) this.expander.getPortByName(portName);
	}
	
	private class DuplicatePhase extends Expander<Double>{

		public DuplicatePhase(int nrOfPorts, SimNode ownNode) {
			super(nrOfPorts, 0.0, ownNode);
		}
		
		@Override
		public void handleMessageIndication(Message msg) {
			Message premsg = inputPort.getMessage();
			for(SynchronousOutputPort out : outputPorts)
				out.sendMessage(premsg);
		}
	

	}

}
