package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ConstantDistribution;
import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.entities.demultiplexers.Demultiplexer;
import ikr.simlib.entities.generators.StdGenerator;
import ikr.simlib.entities.multiplexers.StdMultiplexer;
import ikr.simlib.factories.Factory;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.ports.Port;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.ports.output.SynchronousOutputPort;

public class Multitraffic {
	
	public void method() {
		StdGenerator gen1 = new StdGenerator(new ConstantDistribution(1), null, null, new MeasurementTrafficFactory(), true);
		StdGenerator gen2 = new StdGenerator(new ConstantDistribution(1), null, null, new AdditionalTrafficFactory(), true);
		
		StdMultiplexer mux = new StdMultiplexer(null);
		
		Demultiplexer demux = new Demux(null);
	}
	
	public class Demux extends Demultiplexer {
		
		SynchronousOutputPort out1;
		SynchronousOutputPort out2;
		

		public Demux(SimNode ownNode) {
			super(ownNode);
			out1 = new SynchronousOutputPort(this);
			out2 = new SynchronousOutputPort(this);
		}

		@Override
		protected Port determineOutputPort(Message msg) {
			if(msg instanceof MeasurementMessage) {
				return out1;
			} else {
				return out2;
			}
		}

		@Override
		public OutputPort getOutput(int index) {
			if(index==0) {
				return out1;
			} else {
				return out2;
			}
		}
		
	}

	public class  MeasurementTrafficFactory implements Factory<Message> {

		@Override
		public Message create() {
			return new MeasurementMessage();
		}
	}
	
	public class MeasurementMessage extends Message {
		
	}
	
	public class  AdditionalTrafficFactory implements Factory<Message> {

		@Override
		public Message create() {
			return new AdditionalTrafficMessage();
		}
	}
	
	public class AdditionalTrafficMessage extends Message {
		
	}
}
