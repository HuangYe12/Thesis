package ikr.simlib.example;

import java.util.HashSet;
import java.util.Set;

import ikr.simlib.entities.Entity;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.ports.output.SynchronousOutputPort;

public class Synchronizer extends Entity {

	private final InputPort input1;
	private final InputPort input2;
	
	private final SynchronousOutputPort out;
	
	private Set<Message> observedMessages;

	public Synchronizer(Parameters pars, SimNode ownNode) {
		super(ownNode);
		
		this.observedMessages = new HashSet<>();
		
		this.out = new SynchronousOutputPort(this);

		input1 = new InputPort(this) {

			@Override
			protected void handleMessageIndication(Message msg) {
				handleMessage(this.getMessage());

			}
		};

		input2 = new InputPort(this) {

			@Override
			protected void handleMessageIndication(Message msg) {
				handleMessage(this.getMessage());

			}
		};
	}
	
	public InputPort getInput(int index) {
		if(index == 0)
			return (InputPort) this.input1;
		else
			return (InputPort) this.input2;
	}
	
	public OutputPort getOutput() {
		return (OutputPort) this.out;
	}

	private void handleMessage(Message msg) {
		if(!observedMessages.contains(msg)) {
			observedMessages.add(msg);
		} else {
			observedMessages.remove(msg);
			out.sendMessage(msg);
		}
	}

}
