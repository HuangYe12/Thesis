package TaskGraphAnalysis.src;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.StringTokenizer;

public class FileIO {

  public static void writeto(String FileName, double x1, double x2, double x3, double x4, double x5, double x6) {
    PrintWriter outputStream = null;
    try { // Text file output with PrintWriter
      outputStream = new PrintWriter(new FileOutputStream(FileName, true));
      // outputStream.printf("%-10.2f%-10.2f%-10.3f%-10.3f%-10.5f%-10.3f%n", x1,x2,x3,x4,x5,x6);
      // //append the file if it already exists
      outputStream.printf("%f;%f;%f;%f;%f;%f%n", x1, x2, x3, x4, x5, x6);
    } catch (FileNotFoundException e) {
      System.out.println("Error opening the file:" + FileName);
      System.exit(0);
    }
    outputStream.close();
  }

  public static void writeto(String FileName, int n, double x1, double x2, double x3, double x4) {
    PrintWriter outputStream = null;
    try { // Text file output with PrintWriter
      outputStream = new PrintWriter(new FileOutputStream(FileName, true));
      outputStream.printf("%-10d%-10.2f%-10.2f%-10.5f%-10.3f%n", n, x1, x2, x3, x4); // append the
                                                                                     // file if it
                                                                                     // already
                                                                                     // exists
    } catch (FileNotFoundException e) {
      System.out.println("Error opening the file:" + FileName);
      System.exit(0);
    }
    outputStream.close();
  }

  public static void writeto(String FileName, int n, double x1, double x2, double x3, double x4, double x5) {
    PrintWriter outputStream = null;
    try { // Text file output with PrintWriter
      outputStream = new PrintWriter(new FileOutputStream(FileName, true));
      outputStream.printf("%-10d%-10.2f%-10.2f%-10.5f%-10.3f%-10.5f%n", n, x1, x2, x3, x4, x5); // append
                                                                                                // the
                                                                                                // file
                                                                                                // if
                                                                                                // it
                                                                                                // already
                                                                                                // exists
    } catch (FileNotFoundException e) {
      System.out.println("Error opening the file:" + FileName);
      System.exit(0);
    }
    outputStream.close();
  }

  public static void writeto(String FileName, int n, double x1, double x2, double x3, double x4, double x5, double x6) {
    PrintWriter outputStream = null;
    try { // Text file output with PrintWriter
      outputStream = new PrintWriter(new FileOutputStream(FileName, true));
      outputStream.printf("%-10d%-10.2f%-10.2f%-10.2f%-10.5f%-10.3f%-10.3f%n", n, x1, x2, x3, x4, x5, x6); // append
                                                                                                           // the
                                                                                                           // file
                                                                                                           // if
                                                                                                           // it
                                                                                                           // already
                                                                                                           // exists
    } catch (FileNotFoundException e) {
      System.out.println("Error opening the file:" + FileName);
      System.exit(0);
    }
    outputStream.close();
  }

  public static void inout() {
    // Text file input with BufferedReader
    BufferedReader inputStream = null;
    try {
      Node Node1 = null;
      Node Node2 = null;
      inputStream = new BufferedReader(new FileReader("data.txt"));
      // read in from file data.txt
      String line = inputStream.readLine();
      while (line != null) {
        StringTokenizer wordFinder = new StringTokenizer(line, " ");
        int Tokennum = wordFinder.countTokens();
        String firstToken = wordFinder.nextToken();
        if (firstToken.equals("concatenation")) {
          if (Tokennum == 5) {
            double e1 = Double.parseDouble(wordFinder.nextToken());
            double c1 = Double.parseDouble(wordFinder.nextToken());
            double e2 = Double.parseDouble(wordFinder.nextToken());
            double c2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(e1, c1);
            Node2 = new Node(e2, c2);
          } else if (Tokennum == 7) {
            double h11 = Double.parseDouble(wordFinder.nextToken());
            double h12 = Double.parseDouble(wordFinder.nextToken());
            double q1 = Double.parseDouble(wordFinder.nextToken());
            double h21 = Double.parseDouble(wordFinder.nextToken());
            double h22 = Double.parseDouble(wordFinder.nextToken());
            double q2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(h11, h12, q1);
            Node2 = new Node(h21, h22, q2);
          } else {
            System.out.println("data.out concatenation line input is wrong");
          }
          Concatenation Concatenation1 = new Concatenation();
          if (Concatenation1.SeqOf(Node1, Node2)) {
            // Text file output with PrintWriter
            PrintWriter outputStream = null;
            try {
              outputStream = new PrintWriter(new FileOutputStream("result.txt", true));
              outputStream.println("Concatenation " + Concatenation1.Virtual.getExpectation() + " " + Concatenation1.Virtual.getCoefficient());
              // append the file if it already exists
            } catch (FileNotFoundException e) {
              System.out.println("Error opening the file: result.txt");
              System.exit(0);
            }
            outputStream.close();
          }
        } else if (firstToken.equals("or")) {
          double pro1;
          if (Tokennum == 6) {
            double e1 = Double.parseDouble(wordFinder.nextToken());
            double c1 = Double.parseDouble(wordFinder.nextToken());
            double e2 = Double.parseDouble(wordFinder.nextToken());
            double c2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(e1, c1);
            Node2 = new Node(e2, c2);
          } else if (Tokennum == 8) {
            double h11 = Double.parseDouble(wordFinder.nextToken());
            double h12 = Double.parseDouble(wordFinder.nextToken());
            double q1 = Double.parseDouble(wordFinder.nextToken());
            double h21 = Double.parseDouble(wordFinder.nextToken());
            double h22 = Double.parseDouble(wordFinder.nextToken());
            double q2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(h11, h12, q1);
            Node2 = new Node(h21, h22, q2);
          } else {
            System.out.println("data.out orsplit line input is wrong");
          }
          pro1 = Double.parseDouble(wordFinder.nextToken());
          OrSplit OrSplit1 = new OrSplit();
          if (OrSplit1.OrSplitOf(Node1, Node2, pro1)) {
            PrintWriter outputStream = null;
            try {
              outputStream = new PrintWriter(new FileOutputStream("result.txt", true));
              outputStream.println("or " + OrSplit1.Virtual.getExpectation() + " " + OrSplit1.Virtual.getCoefficient());
              // append the file if it already exists
            } catch (FileNotFoundException e) {
              System.out.println("Error opening the file: result.txt");
              System.exit(0);
            }
            outputStream.close();
          }
        } else if (firstToken.equals("and")) {
          boolean MaxorMin;
          if (Tokennum == 6) {
            double e1 = Double.parseDouble(wordFinder.nextToken());
            double c1 = Double.parseDouble(wordFinder.nextToken());
            double e2 = Double.parseDouble(wordFinder.nextToken());
            double c2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(e1, c1);
            Node2 = new Node(e2, c2);
          } else if (Tokennum == 8) {
            double h11 = Double.parseDouble(wordFinder.nextToken());
            double h12 = Double.parseDouble(wordFinder.nextToken());
            double q1 = Double.parseDouble(wordFinder.nextToken());
            double h21 = Double.parseDouble(wordFinder.nextToken());
            double h22 = Double.parseDouble(wordFinder.nextToken());
            double q2 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(h11, h12, q1);
            Node2 = new Node(h21, h22, q2);
          } else {
            System.out.println("data.out andsplit line input is wrong");
          }
          if (wordFinder.nextToken().equals("t")) {
            MaxorMin = true;
          } else {
            MaxorMin = false;
          }
          AndSplit AndSplit1 = new AndSplit();
          if (AndSplit1.AndSplitOf(Node1, Node2, MaxorMin)) {
            // Text file output with PrintWriter
            PrintWriter outputStream = null;
            try {
              outputStream = new PrintWriter(new FileOutputStream("result.txt", true));
              outputStream.println("and " + AndSplit1.Virtual.getExpectation() + " " + AndSplit1.Virtual.getCoefficient());
              // append the file if it already exists
            } catch (FileNotFoundException e) {
              System.out.println("Error opening the file: result.txt");
              System.exit(0);
            }
            outputStream.close();
          }
        } else if (firstToken.equals("iteration")) {
          if (Tokennum == 4) {
            double e1 = Double.parseDouble(wordFinder.nextToken());
            double c1 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(e1, c1);
          } else if (Tokennum == 5) {
            double h11 = Double.parseDouble(wordFinder.nextToken());
            double h12 = Double.parseDouble(wordFinder.nextToken());
            double q1 = Double.parseDouble(wordFinder.nextToken());
            Node1 = new Node(h11, h12, q1);
          } else {
            System.out.println("data.out iteration line input is wrong");
          }

          double temp = Double.parseDouble(wordFinder.nextToken());
          int J;
          double feedback_q;
          boolean ret;
          Iteration Iteration1 = new Iteration();
          if (temp >= 1.0) {
            J = (int) temp;
            ret = Iteration1.IterationOf(Node1, J);
          } else {
            feedback_q = temp;
            ret = Iteration1.IterationOf(Node1, feedback_q);
          }
          if (ret) {
            // Text file output with PrintWriter
            PrintWriter outputStream = null;
            try {
              outputStream = new PrintWriter(new FileOutputStream("result.txt", true));
              outputStream.println("iteration " + Iteration1.Virtual.getExpectation() + " " + Iteration1.Virtual.getCoefficient());
              // append the file if it already exists
            } catch (FileNotFoundException e) {
              System.out.println("Error opening the file: result.txt");
              System.exit(0);
            }
            outputStream.close();
          }
        } else {
          System.out.println("no meaning line");
        }
        line = inputStream.readLine();
      }
      inputStream.close();
    } catch (FileNotFoundException e) {
      System.out.println("Error: file data.txt not found!");
      System.out.println("Error: or could not be opened.");
    } catch (IOException e) {
      System.out.println("Error: when reading from file data.txt");
    }
  }
}
