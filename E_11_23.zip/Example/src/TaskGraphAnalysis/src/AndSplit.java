package TaskGraphAnalysis.src;
import java.text.DecimalFormat;

public class AndSplit {
  Node Virtual;

  public boolean AndSplitOf(Node node1, Node node2, boolean MaxOrMin) {
    double E, SecondM, V, c, exp1, exp2, rest, a;
    double h11 = node1.geth1();
    double h12 = node1.geth2();
    double q1 = node1.getq();
    double h21 = node2.geth1();
    double h22 = node2.geth2();
    double q2 = node2.getq();
    if (h22 == 0 && h12 == 0) {
      exp1 = exp2 = rest = a = 0;
    } else if (h22 == 0) {
      exp1 = 0;
      exp2 = Math.exp((h11 - h21) / h12);
      rest = q1 * q2 * h12 * h22 / (h12 + h22);
      a = 0;
    } else if (h12 == 0) {
      exp1 = Math.exp((h21 - h11) / h22);
      exp2 = 0;
      rest = q1 * q2 * h12 * h22 / (h12 + h22);
      a = 0;
    } else {
      exp1 = Math.exp((h21 - h11) / h22);
      exp2 = Math.exp((h11 - h21) / h12);
      rest = q1 * q2 * h12 * h22 / (h12 + h22);
      a = 1 / (1 / h12 + 1 / h22);
    }
    if (MaxOrMin) {
      if (h11 > h21) {
        E = h11 + q1 * h12 + exp1 * (q2 * h22 - rest);
        SecondM = h11 * h11 + 2 * q1 * h12 * (h11 + h12) + q2 * exp1 * 2 * h22 * (h11 + h22) - q1 * q2 * exp1 * 2 * a * (h11 + a);
      } else if (h11 < h21) {
        E = h21 + q2 * h22 + exp2 * (q1 * h12 - rest);
        SecondM = h21 * h21 + 2 * q2 * h22 * (h21 + h22) + q1 * exp2 * 2 * h12 * (h21 + h12) - q1 * q2 * exp2 * 2 * a * (h21 + a);
      } else {
        E = h11 * (2 - q1 - q2 + q1 * q2) + q1 * h12 + q2 * h22 - rest;
        SecondM = h11 * h11 * (2 - q1 - q2 + q1 * q2) + 2 * q1 * h12 * (h11 + h12) + 2 * q2 * h22 * (h11 + h22) - q1 * q2 * 2 * a * (h11 + a);
      }
    } else {
      if (h11 > h21) {
        E = h21 + q2 * h22 - exp1 * (q2 * h22 - rest);
        SecondM = h21 * h21 + 2 * q2 * h22 * (h21 + h22) - q2 * exp1 * 2 * h22 * (h11 + h22) + q1 * q2 * exp1 * 2 * a * (h11 + a);
      } else if (h11 < h21) {
        E = h11 + q1 * h12 - exp2 * (q1 * h12 - rest);
        SecondM = h11 * h11 + 2 * q1 * h12 * (h11 + h12) - q1 * exp2 * 2 * h12 * (h21 + h12) + q1 * q2 * exp2 * 2 * a * (h21 + a);
      } else {
        E = q1 * h11 + q2 * h11 - q1 * q2 * h11 + rest;
        SecondM = h11 * h11 * (q1 + q2 - q1 * q2) + q1 * q2 * 2 * a * (h11 + a);
      }
    }
    if (E == 0) {
      System.out.println("add AndSplit error: E is 0!");
      return false;
    }
    V = SecondM - Math.pow(E, 2);
    c = Math.sqrt(V / Math.pow(E, 2));
    this.Virtual = new Node(E, c);
    Node.CountDecre();
    Node.CountDecre();
    /*
     * if(AndSplit.verify(node1,node2,this.Virtual,MaxOrMin)){ return true; } else {
     * System.out.println("add AndSplit failed!"); return false; }
     */
    return true;
  }

  // only verifies if c=0
  public static boolean verify(Node node1, Node node2, Node virtual, boolean MaxOrMin) {
    DecimalFormat df = new DecimalFormat("####.00");
    double E_reference;
    double E1 = node1.getExpectation();
    double E2 = node2.getExpectation();
    double E3 = virtual.getExpectation();
    if (MaxOrMin) {
      E_reference = Math.max(E1, E2);
    } else {
      E_reference = Math.min(E1, E2);
    }

    if (df.format(E3).equals(df.format(E_reference))) {
      System.out.println("AndSplit: Expectation Verification ok!");
      return true;
    } else {
      System.out.println("AndSplit: Expectation Verification wrong!");
      System.out.println("virtual.Expectation is: " + virtual.getExpectation());
      System.out.println("Reference value is: " + E_reference);
      return false;
    }
  }
}
