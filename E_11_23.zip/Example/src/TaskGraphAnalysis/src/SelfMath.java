package TaskGraphAnalysis.src;
public class SelfMath {
  /* calculate the summation of (A^i/i!), when i range from 0 to n-1 */
  public static double Sigma(double A, int n) {
    double sum = 0.0;
    for (int i = 0; i <= n - 1; i++) {
      sum += Math.pow(A, i) / SelfMath.Fact(i);
    }
    return sum;
  }

  /* calculate the factorial of n */
  public static double Fact(int n) {
    double factorial = 1.0;
    for (int i = 1; i <= n; i++) {
      factorial = factorial * i;
    }
    return factorial;
  }

  /* calculate the summation of (A!/i!)*(x^(n-i)), when i range from 0 to n-1 */
  public static double Sigma_extend(int A, int n, double x) {
    double sum = 0.0;
    for (int i = 0; i <= n - 1; i++) {
      sum += Math.pow(x, n - i) * SelfMath.Fact(A) / SelfMath.Fact(i);
    }
    return sum;
  }

}
