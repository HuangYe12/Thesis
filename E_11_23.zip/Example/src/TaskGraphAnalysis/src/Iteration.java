package TaskGraphAnalysis.src;
import java.text.DecimalFormat;

public class Iteration {
  Node Virtual;

  public boolean IterationOf(Node node1, double feedbackQ) {
    double E, V, c; // variables for the virtual node
    double EOfJ, SecMOfJ, VarOfJ; // variables for the number of iterations
    if (feedbackQ < 0 || feedbackQ >= 1) {
      System.out.println("add Iteration error: Invalid feedback Probability!");
      return false;
    }
    double h11 = node1.geth1();
    double h12 = node1.geth2();
    double q1 = node1.getq();

    EOfJ = 1 / (1 - feedbackQ);
    SecMOfJ = (1 + feedbackQ) / Math.pow((1 - feedbackQ), 2);
    VarOfJ = SecMOfJ - Math.pow(EOfJ, 2);
    E = EOfJ * (h11 + q1 * h12);
    V = EOfJ * node1.getVar() + VarOfJ * Math.pow(node1.getExpectation(), 2);
    if (E == 0) {
      System.out.println("add Iteration error: E is 0!");
      return false;
    }
    c = Math.sqrt(V / Math.pow(E, 2));
    this.Virtual = new Node(E, c);
    Node.CountDecre();
    Node.CountDecre();
    /*
     * if(Iteration.verify(node1,this.Virtual,feedbackQ)){ return true; } else {
     * System.out.println("add Iteration failed!"); return false; }
     */
    return true;
  }

  public boolean IterationOf(Node node1, int J) {
    double E, V, c; // variables for the virtual node
    if (J < 1) {
      System.out.println("add Iteration error: Invalid number of repetitions!");
      return false;
    }
    double h11 = node1.geth1();
    double h12 = node1.geth2();
    double q1 = node1.getq();

    E = J * (h11 + q1 * h12);
    V = J * node1.getVar();
    if (E == 0) {
      System.out.println("add Iteration error: E is 0!");
      return false;
    }
    c = Math.sqrt(V / Math.pow(E, 2));
    this.Virtual = new Node(E, c);
    Node.CountDecre();
    Node.CountDecre();
    /*
     * if(Iteration.verify(node1,this.Virtual,feedbackQ)){ return true; } else {
     * System.out.println("add Iteration failed!"); return false; }
     */
    // Text file output with PrintWriter
    /*
     * PrintWriter outputStream = null; try { outputStream= new PrintWriter(new
     * FileOutputStream("result.txt", true)); outputStream.println("iteration " + E +" "+
     * c);//append the file if it already exists } catch(FileNotFoundException e){
     * System.out.println("Error opening the file: result.txt"); System.exit(0); }
     * outputStream.close();
     */
    return true;
  }

  public static boolean verify(Node node1, Node virtual, double feedbackQ) {
    DecimalFormat df = new DecimalFormat("####.00");
    double E_reference;
    double E1 = node1.getExpectation();
    E_reference = (1 / (1 - feedbackQ)) * E1;
    if (df.format(virtual.getExpectation()).equals(df.format(E_reference))) {
      System.out.println("Iteration: Expectation Verification ok!");
      return true;
    } else {
      System.out.println("Iteration: Expectation Verification wrong!");
      System.out.println("virtual.Expectation is: " + virtual.getExpectation());
      System.out.println("Reference value is: " + E_reference);
      return false;
    }
  }
}
