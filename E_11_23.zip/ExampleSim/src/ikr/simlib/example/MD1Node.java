package ikr.simlib.example;

import ikr.simlib.entities.Entity;
import ikr.simlib.model.SimNode;

public class MD1Node extends Entity{

	public MD1Node(SimNode ownNode) {
		super(ownNode);
		// TODO Auto-generated constructor stub
	}
	
}
