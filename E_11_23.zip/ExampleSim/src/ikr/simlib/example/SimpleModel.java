/*
 * Copyright (C) 2007-2014 University of Stuttgart, IKR
 * 
 * This file is part of IKR SimLib, Java Edition, as available from
 * http://www.ikr.uni-stuttgart.de/IKRSimLib.
 * 
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License (LGPL) as published by the
 * Free Software Foundation, in version 2.1 as it comes in the file "COPYING" in
 * directory doc of IKR SimLib.
 * 
 * IKR SimLib is distributed in the hope that it will be useful, but without any
 * warranty of any kind. See the LGPL for details or contact the IKR if you need
 * additional information (http://www.ikr.uni-stuttgart.de).
 * 
 * Alternatively you may license IKR SimLib under a different (non-free)
 * license. Please contact the IKR for further details.
 */

package ikr.simlib.example;

import ikr.simlib.control.simulationcontrol.ControlTimer;
import ikr.simlib.entities.generators.Generator;
import ikr.simlib.entities.sinks.Sink;
import ikr.simlib.events.time.Duration;
import ikr.simlib.meters.time.TimeMeter;
import ikr.simlib.model.Model;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.statistics.distribution.StdDistributionStatistic;
import ikr.simlib.statistics.sample.StdSampleStatistic;


public class SimpleModel extends Model {
	
	private final Generator generator;   
	private final MG1Node sw1_to_ctrl, sw2_to_ctrl, ctrl_to_db, db_to_ctrl, ctrl_to_sw2, ctrl_to_sw1;
	private final Duplicator duplicator;
	private final Synchronizer synchronizer;
	private final Sink sink;

	private final TimeMeter meter1;
	private final TimeMeter meter2;

	@SuppressWarnings("unused")
   	private final ControlTimer controlTimer;

	public SimpleModel(Parameters pars) {
		super("ExampleModel");

      // parse model parameters
		final int transientPhaseTime = pars.getOrUseDefault(this.simNode, "TransientPhaseTime", "50").asInteger();
		final int batchTime = pars.getOrUseDefault(this.simNode, "BatchTime", "100").asInteger();

      // create entities
		final SimNode generatorNode = this.simNode.createChildNode("Generator");
		this.generator = pars.get(generatorNode.getFullName()).asInstance(Generator.class, generatorNode, pars);
		//this.node_p = new PacketNode(pars, this.simNode.createChildNode("Node_P"));
		this.node1 = new MM1Node(pars, this.simNode.createChildNode("Node1"));
		this.node2 = new MM1Node(pars, this.simNode.createChildNode("Node2"));
		this.node3 = new MM1Node(pars, this.simNode.createChildNode("Node3"));
		this.node4 = new MM1Node(pars, this.simNode.createChildNode("Node4"));
		this.node5 = new MM1Node(pars, this.simNode.createChildNode("Node5"));
		this.node6 = new MM1Node(pars, this.simNode.createChildNode("Node6"));
		this.node7 = new MM1Node(pars, this.simNode.createChildNode("Node7"));
		this.duplicator = new Duplicator(pars, this.simNode.createChildNode("Duplicator"));
		this.synchronizer = new Synchronizer(pars, this.simNode.createChildNode("Synchronizer"));
		
		this.sink = new Sink(this.simNode.createChildNode("Sink"));

		// create meters
		this.meter1 = TimeMeter.createWithDoubleStatistic(new StdSampleStatistic(this.simNode.createChildNode("TransmissionTimeMeter")));
		this.meter2 = TimeMeter.createWithDoubleStatistic(new StdDistributionStatistic(10, 0, 10, this.simNode.createChildNode("TransmissionTimeDistribution")));

		// create control counter
		this.controlTimer = new ControlTimer(Duration.fromSeconds(transientPhaseTime), Duration.fromSeconds(batchTime));

		// connect entities
		//this.generator.getOutput().connect(this.node_p.getInput());
		//this.node_p.getOutput().connect(this.sink.getInput());

		this.generator.getOutput().connect(this.node1.getInput());
		this.node1.getOutput().connect(this.node2.getInput());
		this.node2.getOutput().connect(this.node3.getInput());
		this.node3.getOutput().connect(this.duplicator.getInput());
		
		this.duplicator.getOutput("output 1").connect(this.node4.getInput());
		this.node4.getOutput().connect(this.node5.getInput());
		this.node5.getOutput().connect(this.synchronizer.getInput(0));
		
		this.duplicator.getOutput("output 2").connect(this.node6.getInput());
		this.node6.getOutput().connect(this.node7.getInput());
		this.node7.getOutput().connect(this.synchronizer.getInput(1));
		
		this.synchronizer.getOutput().connect(this.sink.getInput());
		
		

		// attach meters and control counter
		this.meter1.attachFromPort(this.generator, "output");
      	this.meter1.attachToPort(this.sink, "input");

      	this.meter2.attachFromPort(this.generator, "output");
      	this.meter2.attachToPort(this.sink, "input");

   }
}
