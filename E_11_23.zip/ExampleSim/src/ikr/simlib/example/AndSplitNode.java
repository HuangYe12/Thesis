package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ConstantDistribution;
import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.distributions.continuous.NegExpDistribution;
import ikr.simlib.entities.Entity;
import ikr.simlib.entities.phases.StdPhase;
import ikr.simlib.entities.queues.QueuingEntity;
import ikr.simlib.events.time.Duration;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;

public class AndSplitNode extends Entity {

	private final QueuingEntity queue;
	private final StdPhase phase;
	
	public AndSplitNode(Parameters pars, SimNode ownNode) {
		super(ownNode);


		// create entities
		this.queue = QueuingEntity.createUnboundedFIFOQueue(this.simNode.createChildNode("Queue"));

		final double mean1 = pars.get(simNode, "Mean1").asDouble();
		final double mean2 = pars.get(simNode, "Mean2").asDouble();
		//final double mean3 = pars.get(simNode, "Mean3").asDouble();
		//final double mean4 = pars.get(simNode, "Mean4").asDouble();
		this.phase = new DegeneratedPhase(new ConstantDistribution(mean1), new NegExpDistribution(mean2), this.simNode.createChildNode("Phase"));
		//this.phase2 = new DegeneratedPhase(, this.simNode.createChildNode("Phase2"));

		// connect entities
		this.queue.connect("output", this.phase, "input");
		//this.phase1.connect("output", this.phase2, "input");
	}

	public InputPort getInput() {
		return (InputPort) this.queue.getPortByName("input");
	}

	public OutputPort getOutput() {
		return (OutputPort) this.phase.getPortByName("output");
	}

	private class DegeneratedPhase extends StdPhase {
		private final ContinuousDistribution d2;
		public DegeneratedPhase(ContinuousDistribution d1, ContinuousDistribution d2, SimNode ownNode) {
			super(d1, ownNode);
			this.d2 = d2;
			//this.d3 = d3;
			//this.d4 = d4;
		}

		@Override
		protected Duration getMessageProcessingDuration(Message msg) {
				return Duration.fromSeconds(serviceTime.next() + d2.next());
		}

	}
	
}
