/*
 * Copyright (C) 2007-2014 University of Stuttgart, IKR
 * 
 * This file is part of IKR SimLib, Java Edition, as available from
 * http://www.ikr.uni-stuttgart.de/IKRSimLib.
 * 
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License (LGPL) as published by the
 * Free Software Foundation, in version 2.1 as it comes in the file "COPYING" in
 * directory doc of IKR SimLib.
 * 
 * IKR SimLib is distributed in the hope that it will be useful, but without any
 * warranty of any kind. See the LGPL for details or contact the IKR if you need
 * additional information (http://www.ikr.uni-stuttgart.de).
 * 
 * Alternatively you may license IKR SimLib under a different (non-free)
 * license. Please contact the IKR for further details.
 */

package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.distributions.continuous.NegExpDistribution;
import ikr.simlib.entities.Entity;
import ikr.simlib.entities.phases.StdPhase;
import ikr.simlib.entities.queues.QueuingEntity;
import ikr.simlib.events.time.Duration;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;

public class MM1Node extends Entity {

	private final QueuingEntity queue;
	private final StdPhase phase;

	public MM1Node(Parameters pars, SimNode ownNode) {
		super(ownNode);


		// create entities
		this.queue = QueuingEntity.createUnboundedFIFOQueue(this.simNode.createChildNode("Queue"));

		final double mean = pars.get(simNode, "Mean").asDouble();
		this.phase = new DegeneratedPhase(new NegExpDistribution(mean),this.simNode.createChildNode("Phase"));

		// connect entities
		this.queue.connect("output", this.phase, "input");
	}

	public InputPort getInput() {
		return (InputPort) this.queue.getPortByName("input");
	}

	public OutputPort getOutput() {
		return (OutputPort) this.phase.getPortByName("output");
	}

	private class DegeneratedPhase extends StdPhase {
		
		

		public DegeneratedPhase(ContinuousDistribution d, SimNode ownNode) {
			super(d, ownNode);
		}

		@Override
		protected Duration getMessageProcessingDuration(Message msg) {
				return Duration.fromSeconds(serviceTime.next());
		}

	}
}
