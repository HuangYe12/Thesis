package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ConstantDistribution;
import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.distributions.continuous.NegExpDistribution;
import ikr.simlib.entities.Entity;
import ikr.simlib.entities.demultiplexers.Demultiplexer;
import ikr.simlib.entities.generators.StdGenerator;
import ikr.simlib.entities.multiplexers.StdMultiplexer;
import ikr.simlib.entities.phases.StdPhase;
import ikr.simlib.entities.queues.QueuingEntity;
import ikr.simlib.events.time.Duration;
import ikr.simlib.factories.Factory;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.Port;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.ports.output.SynchronousOutputPort;

public class MG1Node extends Entity{
	private final QueuingEntity queue;
	private final StdPhase phaseD, phaseM;
	private final StdGenerator additionalGenerator;
	private final StdMultiplexer multiplexer;
	private final Demultiplexer demultiplexer;
	
	public MG1Node(Parameters pars, SimNode ownNode) {
		super(ownNode);
		
		// create entities
		final double mean = pars.get(simNode, "AdditionalTraffic").asDouble();
		this.additionalGenerator = new StdGenerator(new NegExpDistribution(mean), null, null, new AdditionalTrafficFactory(), true);
		this.queue = QueuingEntity.createUnboundedFIFOQueue(this.simNode.createChildNode("Queue"));
		final double h1 = pars.get(simNode, "h1").asDouble();
		this.phaseD = new StdPhase(new ConstantDistribution(h1), this.simNode.createChildNode("DPhase"));
		final double h2 = pars.get(simNode, "h2").asDouble(); 
		final double q = pars.get(simNode, "q").asDouble();
		this.phaseM = new DegeneratedPhase(new NegExpDistribution(h2), q, this.simNode.createChildNode("MPhase"));
		this.multiplexer = new StdMultiplexer(this.simNode.createChildNode("Multiplexer"));
		this.demultiplexer = new Demux(this.simNode.createChildNode("Demultiplexer"));
		
		// connect entities
		this.additionalGenerator.getOutput().connect((InputPort)this.multiplexer.getPortByName(this.multiplexer.addPort()));
		this.multiplexer.connect("output", this.queue, "input");
		this.queue.connect("output", this.phaseD, "input");
		this.phaseD.connect("output", this.phaseM, "input");
		this.phaseM.connect("output", this.demultiplexer, "input");
				
	}
	
	public InputPort getInput() {
	      final String inPortName = this.multiplexer.addPort();
	      return (InputPort) this.multiplexer.getPortByName(inPortName);
	}
	
	public OutputPort getOutput() {
		return (OutputPort) this.demultiplexer.getOutput(0);
	}
	
	//TODO maybe need a separate sink to accept the additional traffic
	
	private class DegeneratedPhase extends StdPhase {				
		public DegeneratedPhase(ContinuousDistribution d, double q, SimNode ownNode) {
			super(d, ownNode);
		}
		//TODO probability check
		
		@Override
		protected Duration getMessageProcessingDuration(Message msg) {
				return Duration.fromSeconds(serviceTime.next());
		}

	}
	
	public class  AdditionalTrafficFactory implements Factory<Message> {

		@Override
		public Message create() {
			return new AdditionalTrafficMessage();
		}
	}
	
	public class AdditionalTrafficMessage extends Message {
		
	}
	
	public class Demux extends Demultiplexer {
		
		SynchronousOutputPort out1;
		SynchronousOutputPort out2;
		

		public Demux(SimNode ownNode) {
			super(ownNode);
			out1 = new SynchronousOutputPort(this);
			out2 = new SynchronousOutputPort(this);
		}

		@Override
		protected Port determineOutputPort(Message msg) {
			if(msg instanceof AdditionalTrafficMessage) {
				return out2;
			} else {
				return out1;
			}
		}

		@Override
		public OutputPort getOutput(int index) {
			if(index==0) {
				return out1;
			} else {
				return out2;
			}
		}
		
	}

}
