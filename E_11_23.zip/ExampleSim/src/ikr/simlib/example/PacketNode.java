package ikr.simlib.example;

import ikr.simlib.distributions.continuous.ConstantDistribution;
import ikr.simlib.distributions.continuous.ContinuousDistribution;
import ikr.simlib.entities.Entity;
import ikr.simlib.entities.phases.StdPhase;
import ikr.simlib.entities.queues.QueuingEntity;
import ikr.simlib.events.time.Duration;
import ikr.simlib.messages.Message;
import ikr.simlib.model.SimNode;
import ikr.simlib.parameters.Parameters;
import ikr.simlib.ports.input.InputPort;
import ikr.simlib.ports.output.OutputPort;
import ikr.simlib.random.RandomNumberGenerator;



public class PacketNode extends Entity {
	private final QueuingEntity queue;
	private final StdPhase phase;

	public PacketNode(Parameters pars, SimNode ownNode) {
      super(ownNode);

      // parse node parameters
      final double serverProbability = pars.get(this.simNode, "ServerProbability").asDouble();

      // create entities
      this.queue = QueuingEntity.createUnboundedFIFOQueue(this.simNode.createChildNode("Queue"));// Loss system, queue length = 100 
      final double mean1 = pars.get(this.simNode, "Mean1").asDouble();
      final double mean2 = pars.get(this.simNode, "Mean2").asDouble();
      this.phase = new DegeneratedPhase(new ConstantDistribution(mean1), new ConstantDistribution(mean2), serverProbability, this.simNode.createChildNode("Phase1"));




      // connect entities
  	  this.queue.connect("output", this.phase, "input");
      
   }

	public InputPort getInput() {
      return (InputPort) this.queue.getPortByName("input");
   }

	public OutputPort getOutput() {
      return (OutputPort) this.phase.getPortByName("output");
   }
	
	private class DegeneratedPhase extends StdPhase {
		
		private final double q;
		private final ContinuousDistribution d2;

		public DegeneratedPhase(ContinuousDistribution d1, ContinuousDistribution d2, double q, SimNode ownNode) {
			super(d1, ownNode);
			this.q = q;
			this.d2 = d2;
		}

		@Override
		protected Duration getMessageProcessingDuration(Message msg) {
			final double prob = RandomNumberGenerator.getSystemRNG().next();
			if(prob <= q) {
				return Duration.fromSeconds(serviceTime.next());
			} else {
				return Duration.fromSeconds(d2.next());
			}
		}

	}
}
